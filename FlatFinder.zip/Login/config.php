<?php
    $conn = mysqli_connect("localhost","root","","prototype"); //"searchbar"<--Change to your database name

    
?>